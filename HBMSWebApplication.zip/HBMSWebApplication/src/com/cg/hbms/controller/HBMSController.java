package com.cg.hbms.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.service.IHBMSService;

@Controller
public class HBMSController 
{
	@Autowired
	IHBMSService hbmsService;
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "Welcome";
	}
	@RequestMapping(value="frmlogin",method=RequestMethod.GET)
	public String getOptions()
	{
		return "Options";
	}
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String search()
	{
		return "SearchHotel";
	}
	@RequestMapping(value="searchHotel",method=RequestMethod.GET)
	public ModelAndView searchHotel(@RequestParam("city") String city)
	{
		List<Hotels> myData = hbmsService.showAllHotels(city);
		return new ModelAndView("SearchHotel","retHotel",myData);
	}
	@RequestMapping(value="book",method=RequestMethod.GET)
	public String bookHotel(@ModelAttribute("my")BookingDetails bk)
	{
		return "BookHotel";
	}
//	@RequestMapping(value="insertdata",method=RequestMethod.POST)
//	public ModelAndView bookHotel(@Valid @ModelAttribute("my") Hotels htl, 
//			BindingResult result , Map<String,Object> model)
//	{
//		int id;
//		if(result.hasErrors())
//		{
//			List<String> myDom=new ArrayList<>();
//		    myDom.add("Java");
//		    myDom.add("VnV");
//		    myDom.add("dotNet");
//		    model.put("dom", myDom);
//			return new ModelAndView("addtrainee");
//		}
//		else
//		{
//	        id=traineeservice.addTraineeData(tra);
//		} 
//		return new ModelAndView("sucess","edata",id);
//	}
	@RequestMapping(value="viewBooking",method=RequestMethod.GET)
	public String searchUser()
	{
		return "BookingStatus";
	}
	@RequestMapping(value="BookingStatus",method=RequestMethod.GET)
	public ModelAndView viewBooking(@RequestParam("uid") String user_id)
	{
		List<BookingDetails> bookData = hbmsService.getBookingStatus(user_id);
		return new ModelAndView("ViewBookingStatus","bookingStatus",bookData);
	}
	@RequestMapping(value="cancel",method=RequestMethod.GET)
	public String cancelBooking()
	{
		return "CancelBookings";
	}
	@RequestMapping(value="cancelBook",method=RequestMethod.GET)
	public ModelAndView cancelUser(@RequestParam("uid") String user_id)
	{
		List<BookingDetails> bookData = hbmsService.getBookingStatus(user_id);
		return new ModelAndView("ViewCancelBooking","bookingStatus",bookData);
	}
	@RequestMapping(value="bCancel",method=RequestMethod.GET)
	public String bookCancelled(@RequestParam("id") String bookid)
	{
		hbmsService.deleteBooking(bookid);
		return "Cancelled";
	}
	
}
