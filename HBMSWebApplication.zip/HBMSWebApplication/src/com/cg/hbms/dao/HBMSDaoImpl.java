package com.cg.hbms.dao;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;


@Repository("hbmsDao")
public class HBMSDaoImpl implements IHBMSDao
{
	@PersistenceContext
	EntityManager em;

	@Override
	public List<Hotels> showAllHotels(String city)
	{
		Query searchQry=em.createQuery("Select h From Hotels h WHERE h.city=:city");
		searchQry.setParameter("city", city);
		return searchQry.getResultList();
	}

	@Override
	public List<BookingDetails> getBookingStatus(String user_id) 
	{
		Query searchQry2 = em.createQuery("Select b FROM BookingDetails b WHERE userId=:uid");
		searchQry2.setParameter("uid", user_id);
		return searchQry2.getResultList();
	}
	@Override
	public void deleteBooking(String bookid) 
	{
		Query qry=em.createQuery("Delete From BookingDetails Where id=:bid");
		qry.setParameter("bid", bookid);
		qry.executeUpdate();	
	}

	@Override
	public List<RoomDetails> showRooms(String hotel_id) 
	{
		Query showRooms=em.createQuery("SELECT r FROM RoomDetails r WHERE r.hotelId=:htlid");
		showRooms.setParameter("htlid",hotel_id);
		return showRooms.getResultList();
	}

	@Override
	public double generateBill(String roomId, LocalDate bookFrom,LocalDate bookTo) 
	{
		Query billQry=em.createQuery("SELECT r.perNightRate FROM RoomDetails r "
				+ "WHERE room_id=:rid");
		billQry.setParameter("rid",roomId);
		return billQry.executeUpdate();
	}

	@Override
	public void addBooking(BookingDetails book) 
	{
		em.persist(book);
		em.flush();
		//return book.getId();
	}
	
}
