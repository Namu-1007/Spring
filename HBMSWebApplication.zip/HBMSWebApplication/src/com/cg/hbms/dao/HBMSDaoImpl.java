package com.cg.hbms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;


@Repository("hbmsDao")
public class HBMSDaoImpl implements IHBMSDao
{
	@PersistenceContext
	EntityManager em;

	@Override
	public List<Hotels> showAllHotels(String city)
	{
		Query searchQry=em.createQuery("Select h From Hotels h WHERE h.city=:city");
		searchQry.setParameter("city", city);
		return searchQry.getResultList();
	}

	@Override
	public List<BookingDetails> getBookingStatus(String user_id) 
	{
		Query searchQry2 = em.createQuery("Select b FROM BookingDetails b WHERE userId=:uid");
		searchQry2.setParameter("uid", user_id);
		return searchQry2.getResultList();
	}


	@Override
	public void deleteBooking(String bookid) 
	{
		Query qry=em.createQuery("Delete From BookingDetails Where id=:bid");
		qry.setParameter("bid", bookid);
		qry.executeUpdate();	
	}
	
}
