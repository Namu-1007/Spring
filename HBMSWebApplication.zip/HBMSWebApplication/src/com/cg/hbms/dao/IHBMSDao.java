package com.cg.hbms.dao;

import java.util.List;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
 
public interface IHBMSDao 
{
	public List<Hotels>showAllHotels(String city);
	public List<BookingDetails> getBookingStatus(String user_id);
	public void deleteBooking(String bookid);
}
