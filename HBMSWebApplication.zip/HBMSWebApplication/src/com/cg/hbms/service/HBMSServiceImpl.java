package com.cg.hbms.service;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbms.dao.IHBMSDao;
import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;
@Service("hbmsService")
@Transactional
public class HBMSServiceImpl implements IHBMSService
{
	@Autowired
	IHBMSDao hbmsDao;
	@Override
	public List<Hotels> showAllHotels(String city) 
	{
		return hbmsDao.showAllHotels(city);
	}
	@Override
	public List<BookingDetails> getBookingStatus(String user_id)
	{
		return hbmsDao.getBookingStatus(user_id);
	}
	@Override
	public void deleteBooking(String bookid)
	{
		 hbmsDao.deleteBooking(bookid);	
	}
	@Override
	public List<RoomDetails> showRooms(String hotel_id) 
	{
		return hbmsDao.showRooms(hotel_id);
	}
	@Override
	public double generateBill(String roomId, LocalDate bookFrom,LocalDate bookTo) 
	{
		List<RoomDetails> rooms=hbmsDao.getRoomDetails(roomId);//new RoomDetails();
		double amount=0.0;
		for(RoomDetails rm: rooms)
		{
			amount = rm.getPerNightRate();
		}
         int numberOfDays=bookTo.getDayOfYear()-bookFrom.getDayOfYear();
         
         System.out.println(amount +" "+ numberOfDays);
        double billAmount=amount*numberOfDays;
		return billAmount;
	}
	@Override
	public String addBooking(BookingDetails book)
	{
		return hbmsDao.addBooking(book);
	}
	@Override
	public List<String> getAllUserIds() 
	{
		return hbmsDao.getAllUserIds();
	}
	@Override
	public boolean validateUserId(String id) 
	{
		List<String>allIds=(List<String>)hbmsDao.getAllUserIds();
		for(String i:allIds)
		{
			if(i.equals(id))
			{
				return true;
			}
		}
		return false;
	}
	@Override
	public List<String> getAllUserPass() 
	{
		return hbmsDao.getAllUserPass();
	}
	@Override
	public boolean validateUserPass(String pass) 
	{
		List<String>allPass=(List<String>)hbmsDao.getAllUserPass();
		for(String i:allPass)
		{
			if(i.equals(pass))
			{
				return true;
			}
		}
		return false;
	}
	@Override
	public void updateAvail(String roomid) 
	{
		hbmsDao.updateAvail(roomid);
	}

}
