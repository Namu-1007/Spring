package com.cg.hbms.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;

public interface IHBMSService 
{
	public List<Hotels>showAllHotels(String city);
	public List<BookingDetails> getBookingStatus(String user_id);
	public void deleteBooking(String bookid);
	public void addBooking(BookingDetails book);
	public List<RoomDetails> showRooms(String hotel_id);
	public double generateBill(String roomId, LocalDate bookFrom,LocalDate bookTo);
	public void updateAvail(String roomid);
}
