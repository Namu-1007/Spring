package com.cg.hbms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.service.IHBMSService;


@Controller
public class HBMSController 
{
	@Autowired
	IHBMSService hbmsService;
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "Welcome";
	}
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String getLogin()
	{
		return "login";
	}
	@RequestMapping(value="register",method=RequestMethod.GET)
	public String getRegister()
	{
		return "Register";
	}
	@RequestMapping(value="frmlogin",method=RequestMethod.GET)
	public String getOptions()
	{
		return "Options";
	}
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String search()
	{
		return "SearchHotel";
	}
	@RequestMapping(value="searchHotel",method=RequestMethod.GET)
	public ModelAndView searchHotel(@RequestParam("city") String city)
	{
		List<Hotels> myData = hbmsService.showAllHotels(city);
		return new ModelAndView("SearchHotel","retHotel",myData);
	}
	
}
