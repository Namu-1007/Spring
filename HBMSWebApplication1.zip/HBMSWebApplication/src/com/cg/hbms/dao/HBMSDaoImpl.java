package com.cg.hbms.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.cg.hbms.dto.Hotels;


@Repository("hbmsDao")
public class HBMSDaoImpl implements IHBMSDao
{
	@PersistenceContext
	EntityManager em;

	@Override
	public List<Hotels> showAllHotels(String city)
	{
		Query searchQry=em.createQuery("Select h From Hotels h WHERE h.city=:city");
		searchQry.setParameter("city", city);
		return searchQry.getResultList();
	}
}
