package com.cg.hbms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbms.dao.IHBMSDao;
import com.cg.hbms.dto.Hotels;
@Service("hbmsService")
@Transactional
public class HBMSServiceImpl implements IHBMSService
{
	@Autowired
	IHBMSDao hbmsDao;
	@Override
	public List<Hotels> showAllHotels(String city) 
	{
		return hbmsDao.showAllHotels(city);
	}

}
