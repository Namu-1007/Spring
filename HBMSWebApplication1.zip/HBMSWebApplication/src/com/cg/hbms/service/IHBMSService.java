package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.dto.Hotels;

public interface IHBMSService 
{
	public List<Hotels>showAllHotels(String city);
}
