package com.cg.hbms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="roomdetails")
public class RoomDetails 
{
	@Id
	@Column(name="hotel_id")
	private String hotelId;
	@Column(name="room_id")
	private String id;
	@Column(name="room_no")
	private String number;
	@Column(name="room_type")
	private String type;
	@Column(name="per_night_rate")
	private double perNightRate;
	@Column(name="availability")
	private String availability;
	
	public String getHotelId() {
		return hotelId;
	}
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getPerNightRate() {
		return perNightRate;
	}
	public void setPerNightRate(double perNightRate) {
		this.perNightRate = perNightRate;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	@Override
	public String toString() {
		return "RoomDetails [hotelId=" + hotelId + ", id=" + id + ", number="
				+ number + ", type=" + type + ", perNightRate=" + perNightRate
				+ ", availability=" + availability + "]";
	}
	public RoomDetails(String hotelId, String id, String number, String type,
			double perNightRate, String availability) {
		super();
		this.hotelId = hotelId;
		this.id = id;
		this.number = number;
		this.type = type;
		this.perNightRate = perNightRate;
		this.availability = availability;
	}
	public RoomDetails( String id, String number, String type,
			double perNightRate, String availability) {
		super();
		
		this.id = id;
		this.number = number;
		this.type = type;
		this.perNightRate = perNightRate;
		this.availability = availability;
	}
	public RoomDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
