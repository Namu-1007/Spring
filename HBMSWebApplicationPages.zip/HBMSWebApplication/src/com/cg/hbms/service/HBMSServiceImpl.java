package com.cg.hbms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbms.dao.IHBMSDao;
import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
@Service("hbmsService")
@Transactional
public class HBMSServiceImpl implements IHBMSService
{
	@Autowired
	IHBMSDao hbmsDao;
	@Override
	public List<Hotels> showAllHotels(String city) 
	{
		return hbmsDao.showAllHotels(city);
	}
	@Override
	public List<BookingDetails> getBookingStatus(String user_id)
	{
		return hbmsDao.getBookingStatus(user_id);
	}
	@Override
	public void deleteBooking(String bookid)
	{
		 hbmsDao.deleteBooking(bookid);	
	}

}
