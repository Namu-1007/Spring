package com.cg.hbms.dto;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="bookingdetails")
public class BookingDetails 
{
	@Id
	@Column(name="booking_id")
	private String id;
	@Column(name="room_id")
	private String roomId;
	@Column(name="user_id")
	private String userId;
	@Column(name="booked_from")
	private Date bookFrom;
	@Column(name="booked_to")
	private Date bookTo;
	@Column(name="no_of_adults")
	private int noOfAdults;
	@Column(name="no_of_children")
	private int noOfChildren;
	@Column(name="amount")
	private double amount;

	@Override
	public String toString() 
	{
		return "BookingDetails [id=" + id + ", roomId=" + roomId + ", userId=" + userId + ", bookFrom=" + bookFrom
				+ ", bookTo=" + bookTo + ", noOfAdults=" + noOfAdults + ", noOfChildren=" + noOfChildren + ", amount="
				+ amount + "]";
	}

	public BookingDetails( String roomId, String userId, Date bookFrom,Date bookTo, int noOfAdults,
			int noOfChildren, double amount)
	{
		super();
		this.roomId = roomId;
		this.userId = userId;
		this.bookFrom = bookFrom;
		this.bookTo = bookTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
	}

	public BookingDetails(String id, String roomId, String userId, Date bookFrom, Date bookTo, int noOfAdults,
			int noOfChildren, double amount) 
	{
		super();
		this.id = id;
		this.roomId = roomId;
		this.userId = userId;
		this.bookFrom = bookFrom;
		this.bookTo = bookTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
	}
	public BookingDetails(String id, String roomId, String userId, Date bookFrom, Date bookTo, int noOfAdults,
			int noOfChildren) {
		super();
		this.id = id;
		this.roomId = roomId;
		this.userId = userId;
		this.bookFrom = bookFrom;
		this.bookTo = bookTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getBookFrom() {
		return bookFrom;
	}

	public void setBookFrom(Date bookFrom) {
		this.bookFrom = bookFrom;
	}

	public Date getBookTo() {
		return bookTo;
	}

	public void setBooTo(Date bookTo) {
		this.bookTo = bookTo;
	}

	public int getNoOfAdults() {
		return noOfAdults;
	}

	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	public int getNoOfChildren() {
		return noOfChildren;
	}

	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public BookingDetails() {
		super();
		// TODO Auto-generated constructor stub
}
}
