package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;

public interface IHBMSService 
{
	public List<Hotels>showAllHotels(String city);
	public List<BookingDetails> getBookingStatus(String user_id);
}
